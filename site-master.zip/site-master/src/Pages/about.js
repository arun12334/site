import React from 'react'
import { Box } from '@mui/system'
import Layout from '../Layout/layout'


function About() {
  return (
    <div>
      
     <Layout />
  
      <Box >
        hii
      </Box>
      </div>
  )
}

export default About