import React from 'react'
import Layout from '../Layout/layout'

function Help() {
  return (
    <div>
      <Layout />
    </div>
  )
}

export default Help