 
 
 
import Layout from '../Layout/layout'
  

function Home() {
 

 
  

  return (
<div>
<Layout />
    <div>
 
    </div>
</div>
  )
}

export default Home
 
 