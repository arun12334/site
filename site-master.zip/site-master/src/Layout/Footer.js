import React from 'react'

function Footer() {
  return (
    <div> 
<footer className="copyright">
<h6>©2022</h6>
<h6><a href="https://www.antlab.in/" target="blank" style={{color: "blue"}}> antlabs.com. </a></h6>
<h6>All Rights Reserved. </h6>
</footer>









    </div>
  )
}

export default Footer