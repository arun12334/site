import React from 'react'
import Footer from './Footer'
import HeaderPage from './Header'

function Layout() {
  return (
    <div>
        
        <HeaderPage/>
        <Footer/>
    
    </div>
  )
}

export default Layout